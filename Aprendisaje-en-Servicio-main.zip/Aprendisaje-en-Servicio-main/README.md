# Aprendisaje-en-Servicio
Repositorio creado para el proyecto del cole de Aprendizaje en Servicio

PAGINA: https://lukypaint.github.io/Aprendisaje-en-Servicio/


#PASOS PARA AGILIZAR EL PROCESO:

1-Instalarse git https://git-scm.com/download/win

2-Ver un tutorial https://www.youtube.com/watch?v=hWglK8nWh60

3-Abrir la barra de comandos de git en la carpeta donde vayas a clonar el repositorio

4-Clonar el repositorio

5-Mandar los cambios que hagan falta y actualizarlo de vuelta


#CONSEJOS:

Antes de cambiar algo en la rama principal hay que decidirlo en grupo ;)

#COMANDOS:

clone <url del proyecto>: clona el repositorio
  
pull: actualizar carpeta
  
add: añadir archivo al paquete
  
commit: preparar y comentar paquete
  
push: enviar paquete

#RECOMENDABLE: Ver los otros comandos
